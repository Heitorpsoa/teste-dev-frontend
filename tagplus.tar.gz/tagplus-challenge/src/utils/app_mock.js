const INITIAL_APPS = [
    {name: 'Hadoop', color: '#DB00C4', count: 0, insertionHistory: []},
    {name: 'Rails', color: '#3D16F6', count: 0, insertionHistory: []},
    {name: 'Spark', color: '#58EA0D', count: 0, insertionHistory: []},
    {name: 'Orkut', color: '#E95B95', count: 0, insertionHistory: []},
    {name: 'Facebook', color: '#4267B2', count: 0, insertionHistory: []}
    
]

export default INITIAL_APPS