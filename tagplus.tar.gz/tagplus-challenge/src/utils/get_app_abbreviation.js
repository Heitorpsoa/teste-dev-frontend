export default function getAppAbbreviation(name) {
    const VOLWES = ['a', 'e', 'i', 'o', 'u']
    let abbreviation = ''
    for(let i = 0; i < name.length; i++) {
        if ( ! VOLWES.includes(name[i])) {
            abbreviation += name[i]
        }
        if (abbreviation.length == 2)
            return abbreviation
    } 
}