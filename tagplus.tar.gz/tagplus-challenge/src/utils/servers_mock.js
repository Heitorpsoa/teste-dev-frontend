import moment from 'moment'
const INITIAL_SERVERS = [
    {apps: [], createdAt: moment()},
    {apps: [], createdAt: moment()},
    {apps: [], createdAt: moment()},
    {apps: [], createdAt: moment()}

]

export default INITIAL_SERVERS