import React, { useEffect } from 'react'
import getAppAbbreviation from '../utils/get_app_abbreviation'
import increaseColorBrightness from '../utils/increase_color_brightness'

import moment from 'moment'

import './server_frame.css'

export default function ServerFrame({server, deleteServerandUpdateState}) {

    const mainApp = server.apps[0]

    if (!mainApp)
        return <div onClick={()=>deleteServerandUpdateState(server)} className="frame"/>

    const abbreviation = getAppAbbreviation(mainApp.name)
    
    const color = mainApp.color
    const lighterColor = increaseColorBrightness(color, 50)
    
    const upTimeMinutes = moment().subtract(server.createdAt).minutes()

    return (
        <div
            onClick={()=>deleteServerandUpdateState(server)}
            className="frame"
            style={{background:'linear-gradient(130deg,' + color + ',' +lighterColor + ')'}}
        >
            <h1>{abbreviation}</h1>
            <span>
                {server.apps[0]?.name + " / " + (server.apps[1]?.name || "-")}
            </span>
            <span style={{fontWeight: '100'}}>
                Added {upTimeMinutes} minutes ago
            </span>
        </div>
        
    )
}
