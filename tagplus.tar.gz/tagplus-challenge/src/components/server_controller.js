import React from 'react'
import deleteServer from '../useCases/deleteServer'

import './server_controller.css'

export default function ServerController({setServers, servers, apps, setApps, visualErrorTick}) {

    const addServer = (newServer) => setServers(servers => [...servers, newServer])

    const removeLastServer = () => {
        if(servers.length == 0) {
            visualErrorTick()
            return
        }
        
        let server = servers[servers.length - 1]
        let response = deleteServer({server, servers, apps})
        let {newApps, newServers} = response

        setServers(servers => servers.filter(s => newServers.includes(s)))
        setApps(apps => apps.filter(a => newApps.includes(a)))
    }

    return (
        <div className = "controller-container">
            <div className="my-button" onClick={() => addServer({apps: [], createdAt: Date.now()})}>
                
                <div>
                    Adicionar
                </div>
                
                <div className="circle">
                    +
                </div>
            </div>

            <div className="my-button" onClick={removeLastServer}>

                <div>
                    Destruir
                </div>
                
                <div className="circle">
                    -
                </div>
            </div>
        </div>
    )
}
