import React from 'react'
import './app_row.css'

export default function AppRow({app, addApp, removeApp}) {
    
    const {name, color, count} = app

    return (
        <div className="app-row">
            <div style={{width: '20px'}}>
                <span> {name} </span>
            </div>

            <div style={{width: '20px'}}>
                <span className="count"> {count} </span>
            </div>

            <div className="button-container">
                <div className="remove-button" onClick = {()=>removeApp(app)}>-</div>
                <div
                    style = {{backgroundColor: color}}
                    className="add-button"
                    onClick = {()=>addApp(app)}
                >+</div>
            </div>
        </div>
    )
}
