import React from 'react'
import {useState} from 'react'
import AppRow from './app_row'

import './app_manager.css'

export default function AppManager({apps, addApp, removeApp}) {

    return (
        <div className = "manager">
            <p>Apps disponíveis</p>

            {apps.map(app => AppRow({app, addApp, removeApp}))}
        </div>
    )
}
