import React, { useEffect } from 'react'
import ServerFrame from './server_frame'

import './server_board.css'
import deleteServer from '../useCases/deleteServer'

export default function ServerBoard({servers, apps, setServers, setApps}) {
    
    
    const deleteServerandUpdateState = (server) => {
        let response = deleteServer({server, servers, apps})
        let {newApps, newServers} = response

        setServers(servers => servers.filter(s => newServers.includes(s)))
        setApps(apps => apps.filter(a => newApps.includes(a)))
    } 

    return (
        <div className="board">
            <h2>
            Quadros de Servidores
            </h2>
            
            <div className="server-wrap">
                {servers.map(server => ServerFrame({server, deleteServerandUpdateState}))}
            </div>
        </div>
    )
}
