import React from 'react'
import { useState, useEffect } from 'react'
import AppManager from '../components/app_manager'
import ServerBoard from '../components/server_board'
import ServerController from '../components/server_controller'

import addAppInServers from '../useCases/addAppInServers'
import removeAppFromServers from '../useCases/removeAppFromServers'

import INITIAL_APPS from '../utils/app_mock'
import INITIAL_SERVERS from '../utils/servers_mock'
import sleep from '../utils/sleep'

import './dashboard.css'

export default function Dashboard() {
    
    const [servers, setServers] = useState(INITIAL_SERVERS)
    const [apps, setApps] = useState(INITIAL_APPS)
    const [error, setError] = useState()
    const [loading, setLoading] = useState(true)

    useEffect(async () => {
        await sleep(3000)
        setLoading(false)
        console.log('Apareci aqui')
    }, [])

    const visualErrorTick = async () => {
        setError(true)
        await sleep(10)
        setError(false)
    }

    const handleErrorAndUpdateState = async ({success, newApp, newServers}) => {
        if (success) {
            // Setando novo app no array de apps do estado
            setApps(oldApps => oldApps.map(oldApp => {
                if (oldApp.name === newApp.name) {
                    return newApp
                } else {
                    return oldApp
                }
            }))

            setServers(newServers)
        } else {
            visualErrorTick()
        }
    }


    const addAppInServersAndUpdateState = (app) => {
        const response = addAppInServers({app, servers})
        handleErrorAndUpdateState(response)
    }


    const removeAppInServersAndUpdateState = (app) => {
        const response = removeAppFromServers({app, servers})
        handleErrorAndUpdateState(response)
    }


    const className = error ? "container error" : "container"
    return (
        <div className = {className}>
            {
                loading ?
                
                <div className = "loading-screen">
                    <div className = "loader"/>
                </div> :


            [
                ServerController({servers, apps, setServers, setApps, visualErrorTick}),

                ServerBoard({servers, apps, setServers, setApps}),

                AppManager({apps, addApp: addAppInServersAndUpdateState, removeApp: removeAppInServersAndUpdateState})
            ]
            }
        </div>
    )
}
