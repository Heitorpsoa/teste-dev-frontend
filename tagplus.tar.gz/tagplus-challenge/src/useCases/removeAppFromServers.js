export default function removeAppFromServers({app, servers}) {
    try {

        let serverIndex = app.insertionHistory.pop()
        let appIndex = servers[serverIndex].apps.indexOf(app)

        servers[serverIndex].apps.splice(appIndex, 1)
        app.count = app.count - 1

        return {success: true, newApp: app, newServers: servers}

    } catch (err) {
        console.log(err)
        return {success: false, err}
    }
}