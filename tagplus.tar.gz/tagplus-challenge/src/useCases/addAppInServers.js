export default function addAppInServers({app, servers, isRealocating}) {
    try {
        const SERVER_CAPACITY = 2
        const orderedServers = servers.slice().sort((s1, s2) => s1.apps.length - s2.apps.length)

        let choosenServer = null
        let index = 0
        // Escolhendo o server de acordo com a prioridade 
        for(let server of orderedServers) {

            // Prioridade sempre do menos ocupado
            for (let i = 0; i < SERVER_CAPACITY; i ++) {
                if (server.apps.length == i) {
                    choosenServer = server
                    break;
                } 
            }

            // Se encontrou um servidor disponível para de buscar
            if (choosenServer)
                break;
            index++
        }

        // Se não encontrou um servidor retorna erro
        if (!choosenServer)
            return {success: false }

        choosenServer.apps.push(app)
        
        app.insertionHistory.push(servers.indexOf(choosenServer))
        
        if (!isRealocating)
            app.count = app.count + 1
        return {success: true, newApp: app, newServers: servers}
    } catch (err) {
        console.log(err)
        return {success: false, err}
    }
}