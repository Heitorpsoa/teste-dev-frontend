import addAppInServers from "./addAppInServers"

export default function deleteServer({server, apps, servers}) {
    let appsToBeRealocated = server.apps
    let serverIndex = servers.indexOf(server)

    // Lidando com os apps que existiam no server
    apps.forEach(app => {
        for (let appToBeRealocated of appsToBeRealocated) {
            if (app.name == appToBeRealocated.name) {

                const {success, newServers, newApp} = addAppInServers({app, servers, isRealocating: true})
                
                if (success) {
                    app = newApp
                } else {
                    app.count -= 1
                    app.insertionHistory = app.insertionHistory.filter(index => index != serverIndex)
                }

            }
        }
    })

    // deletando o server
    servers.splice(serverIndex, 1)

    return {newApps: apps, newServers: servers}
}