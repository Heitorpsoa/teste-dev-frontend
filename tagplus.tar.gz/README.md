
# Teste dev TagPLus

## Tecnologia usadas

Foi utilizado React com a utilização de uma lib externa
 que é a moment para manipulação de datas (usado no uptime do servidor)

## Execução

Para executar o projeto basta estar na raíz do projeto e executar

```
$npm install
$npm start

```
e abrir o seu navegador na porta 3000 se ele não abrir automaticamente
## Detalhes do funcionamento

#### A tela irá piscar em vermelho toda vez em que o usuário tentar:

- destruir um servidor com 0 servidores ativos
- remover uma instância de um app com 0 instâncias ativas.
- adicionar um app com todos os servidores lotados ( ou nenhum servidor executando)

#### O servidor terá a cor do app principal, porém mostrará entre barras o nome dos dois apps que estão executando nele

#### Ao clicar em um servidor ele será excluído

## Dificuldades de implementação

- Não consegui fazer com que o uptime do servidor fosse atualizado a cada segundo, ele só é atualizado visualmente por consequência de outro evento qualquer.

- Talvez a bolinha de adicionar app fique ovalada em outras telas

- Percebi aos 45 do segundo tempo que os apps precisavam ser realocados e não excluídos

## Não consigo executar o projeto e agora ?

- Por favor entre em contato comigo 31 99565-0804 que eu crio um tunelamento e compartilho um link :) 


